package com.example.hykeeds

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder

class Item_Stroller (val ini:Context, val id:MutableList<String>, val nama:MutableList<String>, val harga:MutableList<String>, val deskripsi:MutableList<String>, val foto:MutableList<Int>) : RecyclerView.Adapter<Item_Stroller.ViewHolder> () {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view:View = LayoutInflater.from(parent.context).inflate(R.layout.item_stroller, parent, false)

        return ViewHolder(view)
    }


    class ViewHolder (ItemView:View) : RecyclerView.ViewHolder(ItemView) {
        val txt_nama:TextView = ItemView.findViewById(R.id.txt_nama)
        val txt_harga:TextView = ItemView.findViewById(R.id.txt_harga)
        val txt_deskripsi:TextView = ItemView.findViewById(R.id.txt_deskripsi)
        val btn_edit:TextView = ItemView.findViewById(R.id.btn_edit)
        val btn_hapus:TextView = ItemView.findViewById(R.id.btn_hapus)
    }

    override fun getItemCount(): Int{
        return nama.size
    }

    override fun onBindViewHolder(holder: Item_Stroller.ViewHolder, position: Int ) {
        holder.txt_nama.text = nama.get(position)
        holder.txt_harga.text = harga.get(position)
        holder.txt_deskripsi.text = deskripsi.get(position)

        holder.btn_edit.setOnClickListener {
            val id_terpilih:String = id.get(position)
            val pindah:Intent = Intent(ini,Edit_Stroller::class.java)
            pindah.putExtra("id_terpilih", id_terpilih)
            ini.startActivity(pindah)
        }

        holder.btn_hapus.setOnClickListener {
            val id_terpilih:String = id.get(position)
            val pindah:Intent = Intent(ini,Hapus_Stroller::class.java)
            pindah.putExtra("id_terpilih", id_terpilih)
            ini.startActivity(pindah)
        }
    }
}

