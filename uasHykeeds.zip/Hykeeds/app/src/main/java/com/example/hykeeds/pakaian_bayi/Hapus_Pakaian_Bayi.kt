package com.example.hykeeds.pakaian_bayi

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.hykeeds.R
import com.example.hykeeds.peralatan_bayi.Peralatan_bayi

class Hapus_Pakaian_Bayi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.hapus_pakaian_bayi)

        val id_terpilih: String = intent.getStringExtra("id_terpilih").toString()

        val dbhykeeds: SQLiteDatabase = openOrCreateDatabase("Hykeeds", MODE_PRIVATE, null)
        val stroller = dbhykeeds.rawQuery("DELETE FROM pakaian_bayi WHERE id='$id_terpilih'", null)
        stroller.moveToNext()

        val pindah: Intent = Intent(this, Pakaian_bayi::class.java)
        startActivity(pindah)
    }
}