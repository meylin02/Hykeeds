package com.example.hykeeds

import android.annotation.SuppressLint
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.hykeeds.pakaian_bayi.Pakaian_bayi
import com.example.hykeeds.peralatan_bayi.Peralatan_bayi

class Tambah_Stroller : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tambah_stroller)

        val txt_nama: EditText = findViewById(R.id.txt_namaBarang)
        val txt_harga: EditText = findViewById(R.id.txt_hargaBarang)
        val txt_deskripsi: EditText = findViewById(R.id.txt_deskripsiBarang)
        val btn_tambah: Button = findViewById(R.id.btn_tambah)

        btn_tambah.setOnClickListener {
            val isi_nama:String = txt_nama.text.toString()
            val isi_harga:String = txt_harga.text.toString()
            val isi_deskripsi:String = txt_deskripsi.text.toString()

            val dbhykeeds: SQLiteDatabase = openOrCreateDatabase("Hykeeds", MODE_PRIVATE, null)
            val eksekutor = dbhykeeds.rawQuery("INSERT INTO stroller_bayi(nama, harga, keterangan) VALUES('$isi_nama','$isi_harga','$isi_deskripsi')", null)
            eksekutor.moveToNext()

            val pindah:Intent = Intent(this, Produk_Stroller::class.java)
            startActivity(pindah)
        }


        val btn_kembali: Button = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah:Intent = Intent(this, Produk_Stroller::class.java)
            startActivity(pindah)
        }

    }


}
