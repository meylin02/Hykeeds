package com.example.hykeeds

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class Activity_Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val username: EditText = findViewById(R.id.username)
        val password: EditText = findViewById(R.id.password)
        val btn_login: Button = findViewById(R.id.btn_login)

        btn_login.setOnClickListener {
            val isi_username:String = username.text.toString()
            val isi_password:String = password.text.toString()

            val dbhykeeds: SQLiteDatabase = openOrCreateDatabase("Hykeeds", MODE_PRIVATE, null)

            val query = dbhykeeds.rawQuery("SELECT * FROM admin WHERE nama_admin='$isi_username' AND password_admin='$isi_password'", null)
            val cek = query.moveToNext()



            if (cek)
            {
                val id_admin = query.getString(0)
                val nama_admin = query.getString(1)
                val password_admin = query.getString(2)

                val session: SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
                val buattiket = session.edit()
                buattiket.putString("id_admin", id_admin)
                buattiket.putString("email_admin", nama_admin)
                buattiket.putString("password_admin", password_admin)
                buattiket.commit()

                val pindah: Intent = Intent(this, Dashboard::class.java)
                startActivity(pindah)
            } else {
                Toast.makeText(this, "Email atau Password anda Salah DULLL!!!!", Toast.LENGTH_LONG).show()
            }
        }




    }
}