package com.example.hykeeds

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.hykeeds.peralatan_bayi.Peralatan_bayi

class Hapus_Stroller : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.hapus_stroller)

        val id_terpilih: String = intent.getStringExtra("id_terpilih").toString()

        val dbhykeeds: SQLiteDatabase = openOrCreateDatabase("Hykeeds", MODE_PRIVATE, null)
        val stroller = dbhykeeds.rawQuery("DELETE FROM stroller_bayi WHERE id='$id_terpilih'", null)
        stroller.moveToNext()

        val pindah: Intent = Intent(this, Produk_Stroller::class.java)
        startActivity(pindah)

    }
}