package com.example.hykeeds.pakaian_bayi

import android.annotation.SuppressLint
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.example.hykeeds.R
import com.example.hykeeds.peralatan_bayi.Peralatan_bayi

class Edit_Pakaian_Bayi : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.edit_pakaian_bayi)


        val id_terpilih:String = intent.getStringExtra("id_terpilih").toString()

        val dbhykeeds: SQLiteDatabase = openOrCreateDatabase("Hykeeds", MODE_PRIVATE, null)
        val ambil = dbhykeeds.rawQuery("SELECT * FROM pakaian_bayi WHERE id = '$id_terpilih'", null)
        ambil.moveToNext()

        val isi_nama:String = ambil.getString(1)
        val isi_harga:String = ambil.getString(2)
        val isi_deskripsi:String = ambil.getString(3)

        val txt_nama: EditText = findViewById(R.id.txt_namaBarang)
        val txt_harga: EditText = findViewById(R.id.txt_hargaBarang)
        val txt_deskripsi: EditText = findViewById(R.id.txt_deskripsiBarang)
        val btn_edit: Button = findViewById(R.id.btn_edit)

        txt_nama.setText(isi_nama)
        txt_harga.setText(isi_harga)
        txt_deskripsi.setText(isi_deskripsi)

        btn_edit.setOnClickListener {
            val nama_baru:String = txt_nama.text.toString()
            val harga_baru:String = txt_harga.text.toString()
            val deskripsi_baru:String = txt_deskripsi.text.toString()

            val ubah = dbhykeeds.rawQuery("UPDATE pakaian_bayi SET nama='$nama_baru', harga='$harga_baru', keterangan='$deskripsi_baru' WHERE id='$id_terpilih'", null)
            ubah.moveToNext()

            val pindah: Intent = Intent(this, Pakaian_bayi::class.java)
            startActivity(pindah)
        }

        val btn_kembali: Button = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah:Intent = Intent(this, Pakaian_bayi::class.java)
            startActivity(pindah)
        }
    }
}