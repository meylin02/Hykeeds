package com.example.hykeeds.peralatan_bayi

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hykeeds.Activity_Login
import com.example.hykeeds.Dashboard
import com.example.hykeeds.Item_Stroller
import com.example.hykeeds.R
import com.example.hykeeds.Tambah_Stroller

class Peralatan_bayi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.peralatan_bayi)

        val rv_peralatan_bayi: RecyclerView = findViewById(R.id.rv_peralatan_bayi)

        val id:MutableList<String> = mutableListOf()
        val nama:MutableList<String> = mutableListOf()
        val harga:MutableList<String> = mutableListOf()
        val deskripsi:MutableList<String> = mutableListOf()
        val foto:MutableList<Int> = mutableListOf()

        val dbhykeeds: SQLiteDatabase = openOrCreateDatabase("Hykeeds", MODE_PRIVATE, null)
        val ambil = dbhykeeds.rawQuery("SELECT * FROM peralatan_bayi", null)
        while (ambil.moveToNext())
        {
            id.add(ambil.getString(0))
            nama.add(ambil.getString(1))
            harga.add(ambil.getString(2))
            deskripsi.add(ambil.getString(3))
            foto.add(R.drawable.spoon)

        }

        val si: Item_Peralatan_Bayi = Item_Peralatan_Bayi(this, id,nama,harga,deskripsi, foto)

        rv_peralatan_bayi.adapter = si
        rv_peralatan_bayi.layoutManager = GridLayoutManager(this, 1)

        val txt_tambah: TextView = findViewById(R.id.txt_tambah)
        txt_tambah.setOnClickListener {
            val pindah: Intent = Intent(this, Tambah_Peralatan_Bayi::class.java)
            startActivity(pindah)
        }

        val btn_kembali:TextView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah:Intent = Intent(this, Dashboard::class.java)
            startActivity(pindah)
        }


        val btn_logout:TextView = findViewById(R.id.btn_logout)
        btn_logout.setOnClickListener {
            val pindah:Intent = Intent(this, Activity_Login::class.java)
            startActivity(pindah)
        }

    }
}